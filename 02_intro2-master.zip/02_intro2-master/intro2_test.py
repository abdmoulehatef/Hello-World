import numpy as np
import channelCodingLib as lib


def test_cyclgenmat():
    mat1 = lib.cyclgenmat([1, 1, 0, 1], 7)
    mat2 = lib.cyclgenmat([1, 1, 1, 0, 1, 1, 0, 0, 1, 0, 1], 15)
    assert np.all(np.ravel(mat1) == np.ravel(np.array([[1., 1., 0., 1., 0., 0., 0.],
                                                       [0., 1., 1., 0., 1., 0., 0.],
                                                       [0., 0., 1., 1., 0., 1., 0.],
                                                       [0., 0., 0., 1., 1., 0., 1.]])))
    print('mat1')
    print(mat1)
    print('mat2')
    print(mat2)


test_cyclgenmat()


def test_genmatsys():
    mat1_sys, H1 = lib.cyclgenmat([1, 1, 0, 1], 7, True)
    mat2_sys, H2 = lib.cyclgenmat([1, 1, 1, 0, 1, 1, 0, 0, 1, 0, 1], 15, True)
    m, n = np.shape(mat1_sys)
    # identity = np.identity(m)
    print('mat1_sys')
    print(mat1_sys)
    print('H1')
    print(H1)
    print('mat2_sys')
    print(mat2_sys)
    print('H2')
    print(H2)
    # for i in range(m):
    # assert np.all(mat1[i][:m] == identity[i])


test_genmatsys()


def test_syndict():
    g1, h1 = lib.cyclgenmat([1, 1, 0, 1], 7, True)
    g2, h2 = lib.cyclgenmat([1, 1, 1, 0, 1, 1, 0, 0, 1, 0, 1], 15, True)
    dmin1, e1 = lib.codefeatures(g1)
    dmin2, e2 = lib.codefeatures(g2)
    y1 = lib.syndict(h1, e1)
    y2 = lib.syndict(h2, e2)
    print(y1)
    print(len(y2))


def test_encoder():
    G1, H1 = lib.cyclgenmat([1, 1, 0, 1], 7, True)
    G2, H2 = lib.cyclgenmat([1, 1, 1, 0, 1, 1, 0, 0, 1, 0, 1], 15, True)
    x1 = np.array([[1, 0, 1, 0], [0, 0, 0, 1], [1, 1, 1, 1]])
    x2 = np.array([[1, 1, 1, 1, 0], [0, 0, 1, 0, 1]])
    print('X =')
    print(x1)
    print(x2)
    y1 = lib.encoder(G1, x1)
    y2 = lib.encoder(G2, x2)
    print('Y1 =')
    print(y1)
    print('Y2 =')
    print(y2)


def test_decoder():
    G1, H1 = lib.cyclgenmat([1, 1, 0, 1], 7, True)
    G2, H2 = lib.cyclgenmat([1, 1, 1, 0, 1, 1, 0, 0, 1, 0, 1], 15, True)
    x1 = np.array([[1, 0, 1, 0], [0, 0, 0, 1], [1, 1, 1, 1]])
    x2 = np.array([[1, 1, 1, 1, 0], [0, 0, 1, 0, 1]])
    print('X1 =')
    print(x1)
    print('X2 =')
    print(x2)
    y1 = lib.encoder(G1, x1)
    y2 = lib.encoder(G2, x2)
    y1[0][0] = (y1[0][0] + 1) % 2
    y1[0][1] = (y1[0][1] + 1) % 2
    y1[0][2] = (y1[0][2] + 1) % 2
    y1[1][1] = (y1[1][1] + 1) % 2
    y2[1][0] = (y2[1][0] + 1) % 2
    y2[1][1] = (y2[1][1] + 1) % 2
    y2[1][2] = (y2[1][2] + 1) % 2
    y2[0][-1] = (y2[0][-1] + 1) % 2
    print('Y1 =')
    print(y1)
    print('Y2 =')
    print(y2)
    x_dec_1 = lib.decoder(G1, H1, y1)
    x_dec_2 = lib.decoder(G2, H2, y2)
    print('X_dec_1 =')
    print(x_dec_1)
    print('X_dec_2 =')
    print(x_dec_2)


test_decoder()
