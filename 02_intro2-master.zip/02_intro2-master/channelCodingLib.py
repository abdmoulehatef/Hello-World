import numpy as np
import math
import itertools


# Exercise 1
def cyclgenmat(gp, m, systematic=False):
    """
    description:  returns the non-systematic generator matrix to a given
    generator polynomial of a cyclic (m,n) block code.
    Args:
        gp: vector of length m − n + 1 which contains the coefficients of
            the generator polynomial.
        m: specifies the code word length
        systematic: Boolean. G = E|P syntax if True, cyclic if false.
    Returns:
        gen_mat: numpy array with non-systematic generator matrix
    """
    length_gp = len(gp)
    n = 1 + m - length_gp
    genmat = np.zeros((n, m))
    for i in range(n):
        genmat[i, i:(i + length_gp)] = gp
    if systematic:
        sys_genmat = genmatsys(genmat)

        p = sys_genmat[:, n:].copy()
        p = p.T
        e = np.identity(m - n)
        h = np.concatenate((p, e), axis=1)

        return sys_genmat, h
    else:
        return genmat


# Exercise 2
def genmatsys(G):
    """
        converts a given generator matrix to the systematic form
        Args:
            G: numpy.array, generator matrix
        Returns:
            sys_g: systematic generator matrix
    """
    n, m = G.shape
    sys_g = G.copy()

    for i in range(n):
        for j in range(i + 1, n):
            if sys_g[i, j] == 1:
                sys_g[i] = (sys_g[i] + sys_g[j]) % 2

    return sys_g


# Exercise 4
def encoder(G, w):
    return (w @ G) % 2


def de2bi(decimal, n=None):
    """Convert decimal numbers to binary vectors
        Arguments:
            decimal -- integer or iterable of integers
            [n] -- optional, maximum length of representation
        Returns:
            r x n ndarray where each row is a binary vector
        Example:
            de2bi(5)
            -> array([1, 0, 1])
            de2bi(range(6))
            array([[0, 0, 0],
                   [0, 0, 1],
                   [0, 1, 0],
                   [0, 1, 1],
                   [1, 0, 0],
                   [1, 0, 1]])
    """

    if type(decimal) is int:
        decimal = (decimal,)

    if n is None:
        # calculate max length of binary representation
        n = int(np.ceil(np.log2(np.max(decimal) + 1)))

    # create output matrix
    x = np.zeros(shape=(len(decimal), n), dtype=int)
    for i in range(len(decimal)):
        b = bin(decimal[i])[2:]
        x[i, (n - len(b)):] = np.array(list(b))

    return x


# Exercise 5
def codefeatures(G):
    n, m = G.shape
    y = de2bi(range(2 ** n))
    code = (y @ G) % 2  # code word
    weight = np.sum(code, axis=1)
    dmin = min(weight[1:])

    e = math.floor((dmin - 1) / 2)
    if e < 0:
        e = 0
    return dmin, e


# Exercise 6
def syndict(H, e):
    n, m = H.shape
    y = de2bi(range(2 ** m))
    y_filterd = [y[i] for i in range(len(y)) if sum(y[i]) <= e]

    syn_dict = {}
    for error_vector in y_filterd:
        syn = error_vector @ H.T
        syn_dict[tuple(syn)] = error_vector
    # which = np.array(list(itertools.combinations(range(m), e)))
    # grid = np.zeros((len(which), m), dtype="int8")
    #
    # # Magic
    # grid[np.arange(len(which))[None].T, which] = 1
    # b = np.zeros(m)
    # ei = np.vstack((b, grid))  # error vector ei
    # syndrome = ei.dot(H.T) % 2
    # test_dict = dict(zip(ei, syndrome))
    return syn_dict


# Exercise 7
def decoder(G, H, Y):
    dmin, e = codefeatures(G)
    syn_dict = syndict(H, e)
    s = (Y @ H.T) % 2
    n, m = Y.shape
    nG, mG = G.shape
    for i in range(n):
        try:
            error_vector = syn_dict[tuple(s[i])]
        except KeyError:
            error_vector = 0
            print('Error can not be corrected!')
        Y[i] += error_vector
    Y %= 2
    x = Y[:, :nG]
    return x
